#include <boost/any.hpp>
#include <string>

int main()
{
  boost::any a = std::string{"Boost"};
}